#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

#define MAX  100
#define TEMP 0
#define PERM 1
#define NIL -1
#define infinity 9999

/* No of Vertices in the input Graph */
int n = 8;

/* Adjacency Matrix of the input Graph */
int adj[MAX][MAX] =
          {{0,   8,   9,   0,   7,   0,   0,   0},
           {0,   0,   0,   0,   0,   9,   0,   0},
           {5,  -4,   0,   3,   0,   0,   0,   0},
           {0,   3,   6,   0,   0,   4,   0,   0},
           {0,   0,   0,   0,   0,   0,   0,  16},
           {4,   0,   0,   0,   0,   0,  -8,   5},
           {0,   0,   0,   5,   0,   0,   0,   2},
           {0,   0,   0,   0,   0,   0,   0,   0},
          };
int predecessor[MAX];
int pathlength[MAX];
int queue[MAX];
int is_present_in_queue[MAX];
int front, rear;

/* Prints the shortest path & its length */
void findpath(int s, int v)
{
    int i, u;
    int path[MAX]; /* Stores the shortest path */
    int shortdist = 0; /* Stores the length of shortest path */
    int count = 0;
    while(v!=s)
    {
        count++;
        path[count] = v;
        u = predecessor[v];
        shortdist += adj[u][v];
        v = u;
    }
    count++;
    path[count] = s;
    printf("Shortest path is : ");
    for(i=count; i>= 1; i--)
    {
        printf("%d ", path[i]);
    }
    printf("\nShortest distance is : %d\n", shortdist);
}

void initialize_queue()
{
        int i;
        for(i=0; i<MAX; i++)
        {
            queue[i] = 0;
        }
        rear = -1;
        front = -1;
}

int isEmpty_queue()
{
    if(front == -1 || front > rear)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

void insert_queue(int added_item)
{
    if(rear==MAX-1)
    {
        printf("Queue Overflow \n");
        exit(1);
    }
    else
    {
        if(front == -1)
        {
            front = 0;
        }
        rear = rear+1;
        queue[rear] = added_item;
    }
}

int delete_queue()
{
    int d;
    if(front == -1 || front>rear)
    {
        printf("Queue Underflow \n");
        exit(1);
    }
    else
    {
        d = queue[front];
        front = front+1;
    }
    return d;
}

int BellmanFord(int s)
{
    int k=0,i,current;
    for(i=0;i<n;i++)
    {
        predecessor[i] = NIL;
        pathlength[i] = infinity;
        is_present_in_queue[i] = false;
    }
    initialize_queue();
    pathlength[s] = 0;
    insert_queue(s);
    is_present_in_queue[s] = true;
    while(!isEmpty_queue())
    {
        current = delete_queue();
        is_present_in_queue[current] = false;
        if(s == current)
        {
            k++;
        }
        if(k>n)
        {
            return -1;
        }
        for(i=0;i<n;i++)
        {
            if(adj[current][i] != 0)
            {
                if(pathlength[i] > pathlength[current]+adj[current][i])
                {
                    pathlength[i] = pathlength[current]+adj[current][i];
                    predecessor[i] = current;
                    if(!is_present_in_queue[i])
                    {
                        insert_queue(i);
                        is_present_in_queue[i] = true;
                    }
                }
            }
        }
    }
    return 1;
}

int main()
{
    printf("/**********************************/\n");
    printf("/ Executing Bellman Ford Algorithm /\n");
    printf("/**********************************/\n");

    /* Source Vertex */
    int s = 0;

    int flag = BellmanFord(s);

    if(flag == -1)
    {
        printf("Error - Negative cycle present in Graph\n");
        exit(1);
    }

    int v;
    for(v=1; v < n; v++)
    {
        printf("\nFrom Source vertex %d to Vertex %d : \n", s, v);
        if(pathlength[v] == infinity)
        {
            printf("No path exist\n");
        }
        else
        {
            findpath(0, v);
        }
    }

}
