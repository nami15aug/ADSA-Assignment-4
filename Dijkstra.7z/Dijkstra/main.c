#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define MAX  100
#define TEMP 0
#define PERM 1
#define NIL -1
#define infinity 9999

/* No of Vertices in the input Graph */
int n = 8;

/* Adjacency Matrix of the input Graph */
int adj[MAX][MAX] =
          {{0,   8,   2,   7,   0,   0,   0,   0},
           {0,   0,   0,   0,   0,  16,   0,   0},
           {5,   0,   0,   4,   0,   0,   3,   0},
           {0,   0,   0,   0,   9,   0,   0,   0},
           {4,   0,   0,   0,   0,   5,   0,   8},
           {0,   0,   0,   0,   0,   0,   0,   0},
           {0,   0,   6,   3,   4,   0,   0,   0},
           {0,   0,   0,   0,   0,   2,   5,   0},
          };
int predecessor[MAX];
int pathlength[MAX];
int status[MAX];

/* Returns the temporary vertex with min value of Path length.
 * Returns NIL if no temporary vertex is left or all temporary vertices that are left have infinity as pathlength
 */
int min_temp()
{
    int i;
    int min = infinity;
    int k = NIL;
    for(i = 0; i < n; i++)
    {
        if(status[i]==TEMP && pathlength[i]<min)
        {
            min = pathlength[i];
            k = i;
        }
    }
    return k;
}

/* Prints the shortest path & its length */
void findpath(int s, int v)
{
    int i, u;
    int path[MAX]; /* Stores the shortest path */
    int shortdist = 0; /* Stores the length of shortest path */
    int count = 0;
    while(v!=s)
    {
        count++;
        path[count] = v;
        u = predecessor[v];
        shortdist += adj[u][v];
        v = u;
    }
    count++;
    path[count] = s;
    printf("Shortest path is : ");
    for(i=count; i>= 1; i--)
    {
        printf("%d ", path[i]);
    }
    printf("\nShortest distance is : %d\n", shortdist);
}


void Dijkstra(int s)
{
    int i,current;

    /* Making all vertices temporary*/
    for(i=0;i<n;i++)
    {
        predecessor[i] = NIL;
        pathlength[i] = infinity;
        status[i] = TEMP;
    }

    /* Make pathlength of source vertex 0 */
    pathlength[s] = 0;

    while(1)
    {
        /* Search for temporary vertex with minimum pathlength and make it current vertex */
        current = min_temp();

        if(current == NIL)
        {
            return;
        }

        status[current] = PERM;

        for(i=0; i<n; i++)
        {
            /* Checks for adjacent temporary vertices */
            if(adj[current][i] != 0 && status[i] == TEMP)
            {
                if(pathlength[current] + adj[current][i] < pathlength[i])
                {
                    predecessor[i] = current;
                    pathlength[i] = pathlength[current] + adj[current][i];
                }
            }
        }
    }
}


int main()
{
    /* Source Vertex */
    int s = 0;

    Dijkstra(s);

    printf("/**********************************/\n");
    printf("/  Executing Dijkstra Algorithm    /\n");
    printf("/**********************************/\n");

    int v;
    for(v=1; v < n; v++)
    {
        printf("\nFrom Source vertex %d to Vertex %d : \n", s, v);
        if(pathlength[v] == infinity)
        {
            printf("No path exist\n");
        }
        else
        {
            findpath(0, v);
        }
    }

}
